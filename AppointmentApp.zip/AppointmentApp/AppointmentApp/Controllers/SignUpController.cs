﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Models;
using Business;

namespace AppointmentApp.Controllers
{
    public class SignUpController : Controller
    {
        public ActionResult Index()
        {
            return View ();
        }

        [HttpPost]
        public ActionResult Index(PatientInfo patient)
        {
            var patientProfileList = new List<PatientInfo>();
            string firstName = patient.firstName;
            string lastName = patient.lastName;
            string emailId = patient.emailId;
            string password = patient.password;

            patientProfileList = PatientProfile.createPatientProfile(firstName, lastName, emailId , password);

            if (patientProfileList != null && patientProfileList.Count > 0)
            {
                ViewData["firstName"] = patientProfileList[0].firstName;
                ViewData["lastName"] = patientProfileList[0].lastName;
                return View("Success");
            } else
            {
                return View("Failure");
            }
        }
    }
}
