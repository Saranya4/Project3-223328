﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Data;
using DataAccess;

namespace AppointmentService
{
    public class AppointmentService : IAppointmentService
    {
        public DataSet GetPatientProfile(String email, String password)
        {
            return DAPatientInformation.GetPatientProfile(email, password);
        }

        public DataSet CreatePatientProfile(String uniqueId, String firstName, String lastName, String emailId, String password)
        {
            return DAPatientInformation.CreatePatientProfile(uniqueId, firstName, lastName, emailId, password);
        }
    }
}
