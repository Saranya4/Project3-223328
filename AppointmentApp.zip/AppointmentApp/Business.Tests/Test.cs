﻿using NUnit.Framework;
using System;

namespace Business.Tests
{
    [TestFixture]
    public class Test
    {
        [Test]
        public void TestCase()
        {
        }
    }
}
