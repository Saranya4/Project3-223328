﻿using System;
namespace Business
{
    public class Authentication
    {
        public Authentication()
        {
        }
    }
}
