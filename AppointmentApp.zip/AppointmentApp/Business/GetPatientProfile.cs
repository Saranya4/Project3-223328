﻿using System;
namespace Business
{
    public class getPatientProfile
    {
        public getPatientProfile()
        {
        }
    }
}
