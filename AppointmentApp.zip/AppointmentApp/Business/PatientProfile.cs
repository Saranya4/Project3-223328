﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;
using DataAccess;
using System.Data;
using AppointmentService;

namespace Business
{
    public class PatientProfile
    {
        public static List<PatientInfo> createPatientProfile(String firstName, String lastName, String emailId, String password)
        {

            DataSet patientProfilResult = new DataSet();
            var patientProfileList = new List<PatientInfo>();
            Random random = new Random();
            Guid guid = Guid.NewGuid();
            string uniqueId = guid.ToString();
            patientProfilResult = DAPatientInformation.CreatePatientProfile(uniqueId, firstName, lastName, emailId, password);

            if (patientProfilResult.Tables.Count > 0)
            {
                patientProfileList = patientProfilResult.Tables[0].AsEnumerable().Select(mn => new PatientInfo
                {
                    firstName = Convert.ToString(mn["first_name"]),
                    lastName = Convert.ToString(mn["last_name"]),
                    emailId = Convert.ToString(mn["email"])

                }).ToList();
            }
            return patientProfileList;
        }

        public static List<PatientInfo> getPatientProfile(String emailId, String password) {
            DataSet patientProfilResult = new DataSet();

            var patientProfileList = new List<PatientInfo>();

            // Assignment 2 calling Data access layer from business layer
            //patientProfilResult = DAPatientInformation.GetPatientProfile(emailId,password);

            // Assignment 3 calling Service layer from business layer
            var serviceLayer = new AppointmentService.AppointmentServiceClient();
            patientProfilResult = serviceLayer.GetPatientProfile(emailId, password);

            if (patientProfilResult.Tables.Count > 0)
            {
                patientProfileList = patientProfilResult.Tables[0].AsEnumerable().Select( mn => new PatientInfo
                {
                    firstName = Convert.ToString(mn["first_name"]),
                    lastName = Convert.ToString(mn["last_name"]),
                    emailId = Convert.ToString(mn["email"])

                }).ToList();
            }
            return patientProfileList;
        }
    }
}
