﻿using NUnit.Framework;
using System;

namespace DataAccess.Tests
{
    [TestFixture]
    public class Test
    {
        [Test]
        public void TestCase()
        {
        }
    }
}
