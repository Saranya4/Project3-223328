﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Models;
using Business;
using DataAccess;
using System.Data;

namespace Projec.Controllers
{
    public class LoginController : Controller
    {
        public ActionResult Index()
        {
            return View ();
        }

        [HttpPost]
        public ActionResult Index(PatientInfo patient)
        {
            var patientProfileList = new List<PatientInfo>();
            string emailId = patient.emailId;
            string password = patient.password;

            // data access layer
            //DataSet patientProfilResult = new DataSet();

            //patientProfilResult = DAPatientInformation.getPatientProfile(emailId, password);

            //if (patientProfilResult.Tables.Count > 0)
            //{
            //    patientProfileList = patientProfilResult.Tables[0].AsEnumerable().Select(mn => new PatientInfo
            //    {
            //        firstName = Convert.ToString(mn["first_name"]),
            //        lastName = Convert.ToString(mn["last_name"]),
            //        emailId = Convert.ToString(mn["email"])

            //    }).ToList();
            //}

            // business layer
            patientProfileList = PatientProfile.getPatientProfile(emailId, password);

            if(patientProfileList != null && patientProfileList.Count > 0) {
                ViewData["firstName"] = patientProfileList[0].firstName;
                ViewData["lastName"] = patientProfileList[0].lastName;
                return View("Success");
            } else {
                return View("Failure");
            }
        }

        public ActionResult Success()
        {
            return View();
        }

        public ActionResult Failure()
        {
            return View();
        }
    }
}
